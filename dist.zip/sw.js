/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "8bee8505aae9578f6c83f15935a8bec6"
  }, {
    "url": "pwa-512x512.png",
    "revision": "3223647d48c74f09bfcd087579f5b8cc"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f04ebbee5d214e6f4440008cc9cb06bb"
  }, {
    "url": "index.html",
    "revision": "6f00de340682fdcd7c52886d86fa2b90"
  }, {
    "url": "icon-maskable-512.svg",
    "revision": "593bd8fd49d60f1c5638090ed643811e"
  }, {
    "url": "icon-512.svg",
    "revision": "cedbcefb54edef707161ef0d45cc12c6"
  }, {
    "url": "icon-192.svg",
    "revision": "b6040404ac56eae4468154f169878afc"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "3c756d9603a9a4717b5804d7b41369bb"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/purify.es-CKkGSx_G.js",
    "revision": null
  }, {
    "url": "assets/index.es-Ds8Rkx03.js",
    "revision": null
  }, {
    "url": "assets/index-COMHJMvl.js",
    "revision": null
  }, {
    "url": "assets/index-C96HH-K5.css",
    "revision": null
  }, {
    "url": "assets/html2canvas-BRF8fXjN.js",
    "revision": null
  }, {
    "url": "assets/aistudio/image_ee389981.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_eb7211ea.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_ceb8035d.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_ce8bb888.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_c5bd003d.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_bede7e49.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_b740ac3b.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_b55b8203.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_ad23504b.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_8602421d.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_61b6e926.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_5c2d1792.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_3492a7c4.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_27beec9e.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_0b68bb87.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_02b47bcd.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "3c756d9603a9a4717b5804d7b41369bb"
  }, {
    "url": "icon-192.svg",
    "revision": "b6040404ac56eae4468154f169878afc"
  }, {
    "url": "icon-512.svg",
    "revision": "cedbcefb54edef707161ef0d45cc12c6"
  }, {
    "url": "icon-maskable-512.svg",
    "revision": "593bd8fd49d60f1c5638090ed643811e"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f04ebbee5d214e6f4440008cc9cb06bb"
  }, {
    "url": "pwa-512x512.png",
    "revision": "3223647d48c74f09bfcd087579f5b8cc"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "8bee8505aae9578f6c83f15935a8bec6"
  }, {
    "url": "manifest.json",
    "revision": "cc6b2d98e1c3bd4987d3796fb9771c23"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/\.zip(\?.*)?$/i, /^\/\.well-known\//]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
